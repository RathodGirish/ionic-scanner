import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScatchOffReportPage } from './scatch-off-report';

@NgModule({
  declarations: [
    ScatchOffReportPage
  ],
  imports: [
    IonicPageModule.forChild(ScatchOffReportPage)
  ],
  exports: [
    ScatchOffReportPage
  ]
})
export class ActivatePackModule {}
