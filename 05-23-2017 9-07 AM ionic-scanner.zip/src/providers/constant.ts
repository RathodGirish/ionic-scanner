export const GLOBAL_VARIABLE = Object.freeze({
    CONFIRM_PACK_STATUS:'confirm',
    ACTIVATE_PACK_STATUS:'activate'
});