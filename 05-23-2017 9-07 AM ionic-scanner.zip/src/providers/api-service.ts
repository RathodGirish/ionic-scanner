import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { API_URL } from './api-url';
import { CommonService } from './common-service';

@Injectable()
export class APIService {
  constructor( @Inject(Http) private http: Http, public commonService: CommonService) { }

  public getDepartmentsByStoreId(storeId, company_id, callback) { 
    if (storeId === null) {
      return Observable.throw("Please pass store ID");
    } else if (company_id === null) {
      return Observable.throw("Please pass company ID");
    }
    else {
    console.log("" + API_URL.BASE_API_URL + API_URL.GET_DEPARTMENT_BY_STORE_ID + "&store_id=" + storeId+ "&company_id=" + company_id);
      this.http
        .get("" + API_URL.BASE_API_URL + API_URL.GET_DEPARTMENT_BY_STORE_ID + "&store_id=" + storeId+ "&company_id=" + company_id)
        .map(res => res.json())
        .subscribe(
        data => {
          console.log("department data :" + JSON.stringify(data));
          return callback(null, data);
        },
        err => {
          return callback(err, null);
        });
    }
  }

  public getGroceryItemsByStoreId(storeId,company_id, callback) {
    if (storeId === null) {
      return Observable.throw("Please pass store ID");
    } 
   else if (company_id === null) {
      return Observable.throw("Please pass Company ID");
    } 
    else {
      console.log("getGroceryItemsByStoreId : " + API_URL.BASE_API_URL + API_URL.GET_GROCERY_ITEM_BY_STORE_ID + "&store_id=" + storeId+ "&company_id=" + company_id);
      this.http
        .get("" + API_URL.BASE_API_URL + API_URL.GET_GROCERY_ITEM_BY_STORE_ID + "&store_id=" + storeId+ "&company_id=" + company_id)
        .map(res => res.json())
        .subscribe(
        data => {
          console.log("item data :" + JSON.stringify(data));
          return callback(null, data);
        },
        err => {
          return callback(err, null);
        });
    }
  }

  public getScanneItemsByStoreId(storeId,company_id, plu_no, callback) {
    if (storeId === null) {
      return Observable.throw("Please pass store ID");
    } else if(company_id === null){
      return Observable.throw("Please pass Company ID");
    }
    else {
      console.log("getScanneItemsByStoreId : " + API_URL.BASE_API_URL + API_URL.GET_SCANNE_ITEM_BY_STORE_ID + "&store_id=" + storeId+ "&company_id=" + company_id + "&plu_no=" + plu_no);
      this.http
        .get("" + API_URL.BASE_API_URL + API_URL.GET_SCANNE_ITEM_BY_STORE_ID + "&store_id=" + storeId+ "&company_id=" + company_id + "&plu_no=" + plu_no)
        .map(res => res.json())
        .subscribe(
        data => {
          console.log("barcode_items data :" + JSON.stringify(data));
          alert("JSON.stringify(data) :" + JSON.stringify(data))
          return callback(null, data);
        },
        err => {
          return callback(err, null);
        });
    }
  }

  public updateItem(itemId, price, inventory, callback) {
    if (itemId === null) {
      return Observable.throw("Please pass item ID");
    }
    else if (price === null) {
      return Observable.throw("Please pass price");
    }
    else if (inventory === null) {
      return Observable.throw("Please pass inventory");
    }
    else {
      this.http
        .get("" + API_URL.BASE_API_URL + API_URL.UPDATE_ITEM + "&item_id=" + itemId + "&new_price=" + price + "&update_inventory=" + inventory)
        .map(res => res.json())
        .subscribe(
        data => {
          return callback(null, data);
        },
        err => {
          return callback(err, null);
        });
    }
  }

  public addItem(store_id, company_id, plu_no, description, r_grocery_department_id, price, plu_tax, save_to, callback) {
    console.log("store_id :" + store_id + " plu_no :" + plu_no + " description :" + description + " r_grocery_department_id :" + r_grocery_department_id + " price :" + price + " plu_tax :" + plu_tax);
    if (store_id === null) {
      return Observable.throw("Please pass store ID");
    } else if (company_id === null) {
      return Observable.throw("Please pass company id");
    } else if (price === null) {
      return Observable.throw("Please pass price");
    } else if (plu_no === null) {
      return Observable.throw("Please pass plu No");
    } else if (description === null) {
      return Observable.throw("Please pass description");
    } else if (r_grocery_department_id === null) {
      return Observable.throw("Please pass department_id");
    } else if (plu_tax === null) {
      return Observable.throw("Please pass plu_tax");
    } else {

      let body = new FormData();
      body.append('store_id', store_id);
      body.append('plu_no', plu_no);
      body.append('description', description);
      body.append('r_grocery_department_id', r_grocery_department_id);
      body.append('price', price);
      body.append('plu_tax', plu_tax);
      body.append('save_to', save_to);
      body.append('company_id', company_id);

      let headers = new Headers({});
      let options = new RequestOptions({ headers: headers });

      this.http
        .post(API_URL.BASE_API_URL + API_URL.ADD_ITEM, body, options)
        .map(res => res.json())
        .subscribe(
        data => {
          console.log('addItem  ' + JSON.stringify(data));
          if (data.status == '1') {
            return callback(null, data);
          } else {
            return callback(data, null);
          }
        },
        err => {
          console.log("ERROR!: ", err);
          return callback(err, null);
        }
        );
    }
  }

  public getLatestPackByDate(store_id,company_id,date, status, callback) {
    console.log("getLatestPackByDate : " + API_URL.BASE_API_URL + API_URL.GET_LATEST_PACK_BY_DATE + "&store_id=" + store_id+ "&company_id=" + company_id+ "&date=" + date + "&status=" + status);
    this.http
      .get("" + API_URL.BASE_API_URL + API_URL.GET_LATEST_PACK_BY_DATE + "&store_id=" + store_id+ "&company_id=" + company_id+ "&date=" + date + "&status=" + status)
      .map(res => res.json())
      .subscribe(
      data => {
        console.log('getConfirmPackByDate  ' + JSON.stringify(data));
        if (data.status == '1') {
          return callback(null, data);
        } else {
          return callback(data, null);
        }
      },
      err => {
        console.log("ERROR!: ", err);
        return callback(err, null);
      });
  }

  public getScatchReport(company_id,start_date, end_date, storeId, callback) {
    console.log("getScatchReport : " + API_URL.BASE_API_URL + API_URL.GET_SCATCH_REPORT + "&company_id=" + company_id+ "&start_date=" + start_date + "&end_date=" + end_date + "&store_id=" + storeId)
    this.http
      .get("" + API_URL.BASE_API_URL + API_URL.GET_SCATCH_REPORT + "&company_id=" + company_id+ "&start_date=" + start_date + "&end_date=" + end_date + "&store_id=" + storeId)
      .map(res => res.json())
      .subscribe(
      data => {
        if (data.status == '1') {
          return callback(null, data);
        } else {
          return callback(data, null);
        }
      },
      err => {
        console.log("ERROR!: ", err);
        return callback(err, null);
      });
  }

  public confirmPack(body, options, callback) {
    this.http
      .post(API_URL.BASE_API_URL + API_URL.CONFIRM_PACK, body, options)
      .map(res => res.json())
      .subscribe(
      data => {
        console.log('confirmPack  ' + JSON.stringify(data));
        if (this.commonService.isSuccess(data.status)) {
          return callback(null, data);
        } else {
          return callback(data, null);
        }
      },
      err => {
        console.log("ERROR!: ", err);
        return callback(err, null);
      }
      );
  }

  public activePack(body, options, callback) {
    this.http
      .post(API_URL.BASE_API_URL + API_URL.ACTIVATE_PACK, body, options)
      .map(res => res.json())
      .subscribe(
      data => {
        if (this.commonService.isSuccess(data.status)) {
          return callback(null, data);
        } else {
          return callback(data, null);
        }
      },
      err => {
        console.log("ERROR!: ", err);
        return callback(err, null);
      }
      );
  }

  public addGame(body, options, callback) {
    this.http
      .post(API_URL.BASE_API_URL + API_URL.ADD_NEW_GAME, body, options)
      .map(res => res.json())
      .subscribe(
      data => {
        console.log('addGame  ' + JSON.stringify(data));
        if (this.commonService.isSuccess(data.status)) {
          return callback(null, data);
        } else {
          return callback(data, null);
        }
      },
      err => {
        console.log("ERROR!: ", err);
        return callback(err, null);
      }
      );
  }

}


